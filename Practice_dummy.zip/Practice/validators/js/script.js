function formSubmit() {
  let firstName = document.getElementById("fname").value;

  let error_message = "";

  if (
    firstName.length < 5 ||
    firstName.length > 8 ||
    firstName == "" ||
    !isNaN(firstName)
  ) {
    error_message +=
      " first name between 5 and 8 only and cannot have blank or number <br>";
  }

  let lastName = document.getElementById("lname").value;

  if (
    lastName.length < 5 ||
    lastName.length > 8 ||
    lastName == "" ||
    !isNaN(lastName)
  ) {
    error_message +=
      " last name between 5 and 8 only and cannot have blank or number <br>";
  }

  let ageArray = document.getElementsByName("age"); //fetches all the radio buttons with the same name 'lunch' in an array.
  console.log(ageArray);
  let age = ""; //setting a default empty value
  for (ageIndex in ageArray) {
    console.log(ageIndex);
    console.log(ageArray[ageIndex]);

    if (ageArray[ageIndex].checked) {
      age = ageArray[ageIndex].value;
    }
  }
  if (age == "") {
    error_message += "please enter a value for lunch<br>";
  }
  if (error_message !== "") {
    document.getElementById("error_section").innerHTML = error_message;
  } else {
    let finalReciept = `First Name: ${firstName}<br>Last Name: ${lastName}<br> Age: ${age}<br>                   
  `;

    //clear errors and show the output
    document.getElementById("error_section").innerHTML = "";
    document.getElementById("printReciept").innerHTML = finalReciept;
  }
  // Return false will stop the form from submitting and keep it on the current page.//client side
  return false;
}
