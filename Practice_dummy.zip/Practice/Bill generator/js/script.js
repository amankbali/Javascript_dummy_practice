function formSubmit() {
  //type of company
  let carCompany = document.getElementById("company").value;
  var basePrice;
  if (carCompany == "BMW") {
    basePrice = 10000;
  } else {
    basePrice = 20000;
  }

  //type of model
  let carModel = document.getElementById("model").value;
  var baseModelPrice;
  if (carModel == "Sedan") {
    baseModelPrice = 100;
  } else if (carModel == "Sports") {
    baseModelPrice = 200;
  } else {
    baseModelPrice = 300;
  }

  //type of engine
  let carEngine = document.getElementById("engine").value;
  var engineCost;
  if (carEngine == "Petrol") {
    engineCost = 100;
  } else if (carEngine == "Diesel") {
    engineCost = 200;
  } else {
    engineCost = 300;
  }

  //pick a color
  let carColor = document.getElementById("color").value;

  //type of drive
  let driveArray = document.getElementsByName("drive");
  //console.log(genderArray);
  let drive = ""; //setting a default empty value
  for (driveIndex in driveArray) {
    console.log(driveIndex);
    console.log(driveArray[driveIndex]);

    if (driveArray[driveIndex].checked) {
      drive = driveArray[driveIndex].value;
    }
    var costDrive;
    if (drive == "4WD") {
      costDrive = 100;
    } else {
      costDrive = 200;
    }
  }

  //bill calculation
  var bill = baseModelPrice + basePrice + engineCost + costDrive;

  //gst calculation
  var gst = bill * 0.13;
  gst.toFixed(2);

  //final bill calculation
  finalBill = bill + gst;

  //validation and Error messages
  let error_message = "";
  if (carCompany == "") {
    error_message += "choose a car Company <br>";
  }
  if (carModel == "") {
    error_message += "choose a car Model <br>";
  }
  if (carEngine == "") {
    error_message += "choose an Engine type <br>";
  }
  if (carColor == "") {
    error_message += "choose a Color <br>";
  }
  if (drive == "") {
    error_message += "choose a Type of drive <br>";
  }

  //Reciept calculations
  if (error_message !== "") {
    document.getElementById("error_section").innerHTML = error_message;
  } else {
    let finalReciept = ` Base Price of ${carCompany} is $${basePrice} 
  <br> Price of ${carModel} Model is $${baseModelPrice}
  <br> Price of ${carEngine} Type is $${engineCost}
  <br> Type of Color Opted is ${carColor}
  <br> Type of drive selected is ${drive} and cost is $${costDrive}
  <br> Total cost for the car is $${bill}
  <br> GST on the car is $${gst}
  <br> Final Amount of car is $${finalBill}`;

    //clear errors and show the output
    document.getElementById("error_section").innerHTML = "";
    document.getElementById("printReciept").innerHTML = finalReciept;
  }
  // Return false will stop the form from submitting and keep it on the current page.//client side
  return false;
}
