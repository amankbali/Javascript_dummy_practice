function formSubmit() {
  let firstName = document.getElementById("fname").value;

  let lastName = document.getElementById("lname").value;
  let nickName = document.getElementById("nname").value;
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;
  let dob = document.getElementById("dob").value;
  let mobile = document.getElementById("mobile").value;
  let genderArray = document.getElementsByName("gender");
  console.log(genderArray);
  let gender = ""; //setting a default empty value
  for (genderIndex in genderArray) {
    console.log(genderIndex);
    console.log(genderArray[genderIndex]);

    if (genderArray[genderIndex].checked) {
      gender = genderArray[genderIndex].value;
    }
  }

  let address = document.getElementById("address").value;
  let position = document.getElementById("position").value;
  let experience = document.getElementById("experience").value;

  let finalReciept = `Name: ${firstName}<br>
                      Last Name:${lastName}<br>
                      Nick Name:${nickName}<br>
                      Email: ${email}<br>
                      Password:${password}<br>
                      Date Of Birth:${dob}<br>
                      Contact: ${mobile}<br>
                      Gender: ${gender}<br>
                      Address:${address}<br>
                      Applying for:${position}<br>
                      Experience:${experience}
  `;

  //clear errors and show the output
  //document.getElementById("view_result").innerHTML = finalReciept;
  document.getElementById("printReciept").innerHTML = finalReciept;

  // Return false will stop the form from submitting and keep it on the current page.//client side
  return false;
}
